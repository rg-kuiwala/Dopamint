/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Volume2, 
  VolumeX, 
  Play, 
  Pause, 
  Leaf, 
  Coffee,
  Music,
  ExternalLink,
  Download,
  Share2,
  SkipForward
} from 'lucide-react';
import { FluidSimulation } from './components/FluidSimulation';

const TRACKS = [
  { name: "Peaceful Mind", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3" },
  { name: "Deep Focus", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
  { name: "Creative Flow", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" }
];

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(e => console.log("Audio play blocked", e));
      }
      setIsPlaying(!isPlaying);
    }
  };

  const skipTrack = () => {
    const nextIndex = (currentTrackIndex + 1) % TRACKS.length;
    setCurrentTrackIndex(nextIndex);
    setIsPlaying(false);
    // Auto-play next track if it was already playing
    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.play().then(() => setIsPlaying(true));
      }
    }, 100);
  };

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      alert("To install: use your browser's 'Add to Home Screen' option.");
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'DopamintGames',
          text: 'Check out this satisfying fluid simulation for relaxation!',
          url: window.location.href,
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-between p-6 sm:p-10 overflow-hidden selection:bg-emerald-500/30">
      {/* Interactive WebGL Fluid Simulation */}
      <FluidSimulation />
      
      <audio
        ref={audioRef}
        src={TRACKS[currentTrackIndex].url}
        loop
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
      />

      {/* Header - Simple Branding */}
      <header className="w-full flex flex-col items-center z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 bg-black/30 backdrop-blur-xl px-6 py-3 rounded-full border border-white/10 shadow-xl"
        >
          <Leaf size={24} className="text-emerald-400" />
          <h1 className="text-2xl font-black tracking-tighter text-white font-serif">
            Dopamint<span className="text-emerald-400 font-sans italic">Games</span>
          </h1>
        </motion.div>
      </header>

      {/* Main Actions Area */}
      <main className="flex-1 flex flex-col items-center justify-center w-full z-10 px-4">
        <div className="flex flex-wrap items-center justify-center gap-4">
          <motion.a
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            href="https://buymeacoffee.com/rgkuiwala"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-white font-bold text-xs bg-white/5 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/10 hover:bg-white/10 transition-all shadow-xl"
          >
            <Coffee size={16} className="text-amber-400" />
            <span>Support Creator</span>
          </motion.a>

          {deferredPrompt && (
            <motion.button
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleInstall}
              className="flex items-center gap-2 text-white font-bold text-xs bg-emerald-500/10 backdrop-blur-md px-5 py-3 rounded-2xl border border-emerald-500/20 hover:bg-emerald-500/20 transition-all shadow-xl"
            >
              <Download size={16} className="text-emerald-400" />
              <span>Install App</span>
            </motion.button>
          )}

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleShare}
            className="flex items-center gap-2 text-white font-bold text-xs bg-white/5 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/10 hover:bg-white/10 transition-all shadow-xl"
          >
            <Share2 size={16} className="text-blue-400" />
            <span>Share</span>
          </motion.button>
        </div>
      </main>

      {/* Footer - Minimal Controls & Branding */}
      <footer className="w-full max-w-md z-10 space-y-4">
        {/* Subtle Greeting Above Controls */}
        <div className="text-center space-y-1 opacity-60">
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.8 }}
            className="text-white text-[11px] font-black tracking-wider uppercase"
          >
            Have a Nice Day!! RG Kuiwala🔥✍️
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            className="text-emerald-400 text-[7px] font-black uppercase tracking-[0.6em]"
          >
            Mindfulness Simulator
          </motion.p>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-black/40 backdrop-blur-3xl rounded-[2rem] p-5 border border-white/5 shadow-2xl flex items-center gap-5"
        >
          {/* Transparent Small Play Toggle */}
          <button 
            onClick={toggleMusic}
            className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-[10px] transition-all border ${isPlaying ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-white/5 text-white/60 border-white/10 hover:bg-white/10'}`}
          >
            {isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" className="translate-x-0.5" />}
            <span className="uppercase tracking-widest">{isPlaying ? 'Pause' : 'Play'}</span>
          </button>

          {/* Info & Slider */}
          <div className="flex-1 space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-[9px] font-black uppercase tracking-widest text-emerald-400/40 truncate max-w-[100px]">
                {TRACKS[currentTrackIndex].name}
              </span>
              <div className="flex items-center gap-3">
                <button 
                  onClick={skipTrack}
                  className="p-1 text-white/20 hover:text-emerald-400 transition-colors"
                >
                  <SkipForward size={14} />
                </button>
                <span className="text-[9px] font-black tabular-nums text-white/30">{Math.round(volume * 100)}%</span>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <input 
                type="range" 
                min="0" 
                max="1" 
                step="0.01" 
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="flex-1 accent-emerald-500 h-1 bg-white/5 rounded-full appearance-none cursor-pointer"
              />
            </div>
          </div>
        </motion.div>
      </footer>

      <style>{`
        input[type='range']::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 12px;
          height: 12px;
          background: #10b981;
          cursor: pointer;
          border-radius: 50%;
          border: 2px solid #020617;
        }
      `}</style>
    </div>
  );
}

